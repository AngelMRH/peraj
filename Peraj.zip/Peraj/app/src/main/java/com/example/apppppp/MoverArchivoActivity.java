package com.example.apppppp;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MoverArchivoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mover_archivo);

        copiarArchivoAAccesoPublico();
    }

    private void copiarArchivoAAccesoPublico() {
        // Ruta de origen: almacenamiento privado de la aplicación
        File directorio = getExternalFilesDir(null);
        File archivoCSV = new File(directorio, "asistencias.csv");

        // Ruta de destino: directorio público (Ejemplo: Documents)
        File directorioPublico = new File(getExternalFilesDir(null).getAbsolutePath() + "/Documents/");
        if (!directorioPublico.exists()) {
            directorioPublico.mkdir(); // Crear el directorio si no existe
        }

        File archivoDestino = new File(directorioPublico, "asistencias.csv");

        try (FileInputStream fis = new FileInputStream(archivoCSV);
             FileOutputStream fos = new FileOutputStream(archivoDestino)) {

            // Copiar el archivo
            byte[] buffer = new byte[1024];
            int length;
            while ((length = fis.read(buffer)) > 0) {
                fos.write(buffer, 0, length);
            }

            Toast.makeText(this, "Archivo copiado a: " + archivoDestino.getAbsolutePath(), Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al copiar el archivo", Toast.LENGTH_SHORT).show();
        }
    }
}