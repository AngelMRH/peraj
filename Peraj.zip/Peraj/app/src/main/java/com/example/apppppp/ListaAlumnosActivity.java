package com.example.apppppp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class ListaAlumnosActivity extends AppCompatActivity {

    ListView listaAlumnos;
    String[] alumnos = {
            "Ximena Sabalza", "Magali Hernandez", "Judith Ailin Cruz", "Isis Martinez",
            "Aaron Lopez", "Jonathan Cruz", "Diego Hernandez", "Adan Leon", "Raul Perez",
            "Marlon Yabet", "Jimena Geraldine", "Emanuel Corona", "Branda Rosales",
            "Alejandra Elizoldo", "Abigail Hernandez", "Jorge Daniel", "Roberto Cruz",
            "Santiago Sanchez", "Rogelio Vargas", "Brayan Avila"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_alumnos);

        listaAlumnos = findViewById(R.id.listaAlumnos);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, alumnos);
        listaAlumnos.setAdapter(adapter);

        // Configuración del ListView
        listaAlumnos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String alumnoSeleccionado = alumnos[position];
                Intent intent = new Intent(ListaAlumnosActivity.this, RegistroAsistenciaActivity.class);
                intent.putExtra("alumno", alumnoSeleccionado);
                startActivity(intent);
            }
        });

        // Configurar el botón para ver asistencias
        Button btnVerAsistencias = findViewById(R.id.btnVerAsistencias);
        btnVerAsistencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListaAlumnosActivity.this, VerAsistencias.class);
                startActivity(intent);
            }
        });
    }
}
