package com.example.apppppp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class RegistroAsistencia extends AppCompatActivity {

    private static final String TAG = "RegistroAsistencia";
    private static final int REQUEST_CODE_STORAGE_PERMISSION = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_asistencia);

        // Verificar y solicitar permisos si es necesario
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                    REQUEST_CODE_STORAGE_PERMISSION);
        } else {
            generarArchivoCSV();  // Si los permisos ya están concedidos, genera el archivo
        }
    }

    private void generarArchivoCSV() {
        String[] headers = {"Alumno", "Fecha", "Asistencia"};
        String[][] data = {
                {"Ximena Sabalza", "2025-03-01", "Presente"},
                {"Magali Hernandez", "2025-03-01", "Ausente"},
                {"Judith Ailin Cruz", "2025-03-01", "Presente"},
        };

        // Utiliza el almacenamiento público en la carpeta Descargas
        File directorio = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Registros");

        if (!directorio.exists()) {
            boolean creado = directorio.mkdirs();
            Log.d(TAG, "Intentando crear directorio: " + directorio.getAbsolutePath() + " -> " + (creado ? "Éxito" : "Error"));
            if (!creado) {
                Toast.makeText(this, "Error: No se pudo crear el directorio", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // Ruta del archivo
        File archivoCSV = new File(directorio, "asistencias.csv");

        try (FileOutputStream fos = new FileOutputStream(archivoCSV);
             OutputStreamWriter writer = new OutputStreamWriter(fos)) {

            // Escribir los encabezados
            writer.write(String.join(",", headers) + "\n");

            // Escribir las filas de datos
            for (String[] fila : data) {
                writer.write(String.join(",", fila) + "\n");
            }

            // Mostrar la ruta del archivo
            String rutaArchivo = archivoCSV.getAbsolutePath();
            Log.d(TAG, "Archivo guardado en: " + rutaArchivo);
            Toast.makeText(this, "Archivo CSV creado en:\n" + rutaArchivo, Toast.LENGTH_LONG).show();

        } catch (IOException e) {
            Log.e(TAG, "Error al crear el archivo CSV: " + e.getMessage());
            Toast.makeText(this, "Error al crear el archivo CSV", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_STORAGE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Permiso concedido. Creando el archivo CSV...");
                generarArchivoCSV();  // Si el permiso es concedido, generar el archivo
            } else {
                Log.e(TAG, "Permiso denegado. No se puede crear el archivo CSV");
                Toast.makeText(this, "Permiso denegado. No se puede crear el archivo CSV", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
