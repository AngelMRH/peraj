package com.example.apppppp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {

    EditText etUsuario;
    Button btnRegistrarUsuario, btnIniciarSesion;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsuario = findViewById(R.id.etUsuario);
        btnRegistrarUsuario = findViewById(R.id.btnRegistrarUsuario);
        btnIniciarSesion = findViewById(R.id.btnIniciarSesion);

        preferences = getSharedPreferences("Usuarios", MODE_PRIVATE);
        String usuarioRegistrado = preferences.getString("usuario", null);

        // Si ya hay un usuario registrado, activar el inicio de sesión biométrico
        if (usuarioRegistrado != null) {
            showBiometricPrompt();
        }

        btnRegistrarUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrarUsuario();
            }
        });

        btnIniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBiometricPrompt();
            }
        });
    }

    private void registrarUsuario() {
        String usuario = etUsuario.getText().toString().trim();
        if (usuario.isEmpty()) {
            showToast("Ingrese un nombre de usuario");
            return;
        }

        // Guardar el usuario en SharedPreferences
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("usuario", usuario);
        editor.apply();

        showToast("Usuario registrado exitosamente");

        // Iniciar autenticación biométrica después del registro
        showBiometricPrompt();
    }

    private void showBiometricPrompt() {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                showToast("Autenticación biométrica exitosa");
                irAListaAlumnos();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                showToast("Autenticación biométrica fallida");
            }
        });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Autenticación con huella")
                .setSubtitle("Coloca tu huella para iniciar sesión")
                .setNegativeButtonText("Cancelar")
                .build();

        biometricPrompt.authenticate(promptInfo);
    }

    private void irAListaAlumnos() {
        Intent intent = new Intent(MainActivity.this, ListaAlumnosActivity.class);
        startActivity(intent);
        finish(); // Evita volver atrás a la pantalla de login
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
