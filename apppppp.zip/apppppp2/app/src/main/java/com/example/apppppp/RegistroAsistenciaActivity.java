package com.example.apppppp;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.Executor;

public class RegistroAsistenciaActivity extends AppCompatActivity {

    private static final String TAG = "RegistroAsistencia";
    TextView tvAlumno, tvPadre, tvMentor;
    Button btnTomarAsistencia;
    String alumno;

    HashMap<String, String> padresMap;
    HashMap<String, String> mentoresMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_asistencia);

        tvAlumno = findViewById(R.id.tvAlumno);
        tvPadre = findViewById(R.id.tvPadre);
        tvMentor = findViewById(R.id.tvMentor);
        btnTomarAsistencia = findViewById(R.id.btnTomarAsistencia);

        inicializarPadres();
        inicializarMentores();

        // Normaliza el nombre del alumno al recibirlo
        alumno = getIntent().getStringExtra("alumno").trim().toLowerCase();
        tvAlumno.setText("Alumno: " + alumno);

        // Busca el padre/tutor y el mentor con nombres normalizados
        String padre = padresMap.getOrDefault(alumno, "Desconocido");
        String mentor = mentoresMap.getOrDefault(alumno, "No asignado");

        tvPadre.setText("Padre/Tutor: " + padre);
        tvMentor.setText("Mentor: " + mentor);

        btnTomarAsistencia.setOnClickListener(v -> iniciarAutenticacionBiometrica());
    }

    private void inicializarPadres() {
        padresMap = new HashMap<>();
        padresMap.put("ximena sabalza", "Maria Islas");
        padresMap.put("magali hernandez", "Maria Romero");
        padresMap.put("judith ailin cruz", "vacio");
        padresMap.put("isis martinez", "Suset");
        padresMap.put("aaron lopez", "Ala dera Aguirre ");
        padresMap.put("jonathan cruz", "Llego su hermano");
        padresMap.put("diego hernandez", "Kenia Dorantes ");
        padresMap.put("adan leon", "Ofelia ortiz ");
        padresMap.put("raul perez", "Juan Vargas ");
        padresMap.put("marlon yabet", "vacio");
        padresMap.put("jimena geraldine", "Suset ");
        padresMap.put("emanuel corona", "Sara Tapia  ");
        padresMap.put("branda rosales", "Entrego en la entrada ");
        padresMap.put("alejandra elizoldo", "Alejandra Silva");
        padresMap.put("abigail hernandez", "Valeria Hernandez");
        padresMap.put("jorge daniel", "Jorge Rodriguez");
        padresMap.put("roberto cruz", "Sandra ");
        padresMap.put("santiago sanchez", "Adriana Lopez");
        padresMap.put("Rogelio Vargas", "Rosa Vargas");
        padresMap.put("Brayan Avila", "Maria Azucena Ortega ");
    }

    private void inicializarMentores() {
        mentoresMap = new HashMap<>();
        mentoresMap.put("ximena sabalza", "Dara Zurisadai Sanchez Santos");
        mentoresMap.put("magali hernandez", "Amador Miranda Lorent Guadalupe");
        mentoresMap.put("judith ailin cruz", "amador salais maria fernanda");
        mentoresMap.put("isis martinez", "bustos olivares mara naomi");
        mentoresMap.put("aaron lopez","gustavo palaflox martínez");
        mentoresMap.put("jonathan cruz","guerrro jimenez jesse isaac");
        mentoresMap.put("diego hernandez","hernandez fernandez daniel");
        mentoresMap.put("adan leon", "hidalgo lira almir alier");
        mentoresMap.put("raul perez","jardinez maldonado jorge yair");
        mentoresMap.put("jimena geraldine", "lopez leonardo");
        mentoresMap.put("emanuel corona","Martinez Vargas Nicolas");
        mentoresMap.put("marlon yabet","martinez vargas nicolas");
        mentoresMap.put("branda rosales","maurio jimenez luis mario");
        mentoresMap.put("alejandra elizoldo","moncada lazcano rosalba");
        mentoresMap.put("abigail hernandez","perez escorcia ivon leticia");
        mentoresMap.put("jorge daniel","rodolfo galindo ulises");
        mentoresMap.put("roberto cruz","rojas melo jesus valentin");
        mentoresMap.put("santiago sanchez","trejo jimeznez joav zipacna");
        mentoresMap.put("Rogelio Vargas","Efrain Delgadillo ");
        mentoresMap.put("Brayan Avila","karen");
    }

    private void iniciarAutenticacionBiometrica() {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                guardarAsistencia();  // Aquí se guarda la asistencia al autenticarse correctamente
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(RegistroAsistenciaActivity.this, "Huella incorrecta", Toast.LENGTH_SHORT).show();
            }
        });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Autenticación biométrica")
                .setSubtitle("Usa tu huella para registrar la asistencia")
                .setNegativeButtonText("Cancelar")
                .build();

        biometricPrompt.authenticate(promptInfo);
    }

    private void guardarAsistencia() {
        String alumno = getIntent().getStringExtra("alumno");
        String fecha = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String asistencia = "Presente";  // Aquí puedes personalizar dependiendo de la autenticación

        // Ruta para el archivo
        File directorio = new File(getExternalFilesDir(null), "Registros");
        if (!directorio.exists()) {
            directorio.mkdirs(); // Crear directorio si no existe
        }

        // Ruta para el archivo CSV (en lugar de Excel directamente)
        File archivoCSV = new File(directorio, "asistencias.csv");

        try (FileWriter writer = new FileWriter(archivoCSV, true);  // 'true' para agregar al archivo existente
             BufferedWriter bufferedWriter = new BufferedWriter(writer)) {

            // Escribir una línea con el nombre, fecha y asistencia del alumno
            bufferedWriter.write(alumno + "," + fecha + "," + asistencia);
            bufferedWriter.newLine();  // Nueva línea para cada registro

            // Confirmación de que la asistencia se guardó
            Toast.makeText(this, "Asistencia registrada para " + alumno, Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Log.e(TAG, "Error al guardar la asistencia: " + e.getMessage());
            Toast.makeText(this, "Error al guardar la asistencia", Toast.LENGTH_SHORT).show();
        }
    }
}
