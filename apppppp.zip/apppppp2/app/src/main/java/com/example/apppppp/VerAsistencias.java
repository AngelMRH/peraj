package com.example.apppppp;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class VerAsistencias extends AppCompatActivity {

    private static final String TAG = "VerAsistencias";
    private TextView tvContenidoCSV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_asistencias);

        tvContenidoCSV = findViewById(R.id.tvContenidoCSV);
        mostrarContenidoCSV();
    }

    private void mostrarContenidoCSV() {
        // Definir la misma ruta donde se guardó el archivo en RegistroAsistencia.java
        File directorio = new File(getExternalFilesDir(null), "Registros");

        // Verificar si el directorio existe
        if (!directorio.exists()) {
            Log.e(TAG, "El directorio 'Registros' no existe.");
            Toast.makeText(this, "No hay registros disponibles", Toast.LENGTH_SHORT).show();
            return;
        }

        // Ruta correcta del archivo CSV
        File archivoCSV = new File(directorio, "asistencias.csv");

        // Verificar si el archivo existe
        if (!archivoCSV.exists()) {
            Toast.makeText(this, "❌ Archivo no encontrado", Toast.LENGTH_LONG).show();
            Log.e(TAG, "El archivo CSV no existe en la ruta: " + archivoCSV.getAbsolutePath());
            return;
        }

        // Mostrar la ruta completa del archivo para depuración
        Log.d(TAG, "Archivo encontrado en: " + archivoCSV.getAbsolutePath());

        // Si el archivo existe, leerlo
        try (BufferedReader reader = new BufferedReader(new FileReader(archivoCSV))) {
            StringBuilder contenido = new StringBuilder();
            String linea;
            while ((linea = reader.readLine()) != null) {
                contenido.append(linea).append("\n");
            }
            tvContenidoCSV.setText(contenido.toString());
        } catch (IOException e) {
            Log.e(TAG, "Error al leer el archivo CSV: " + e.getMessage());
            Toast.makeText(this, "Error al leer el archivo CSV", Toast.LENGTH_SHORT).show();
        }
    }
}
